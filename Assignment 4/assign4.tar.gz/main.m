%% MyMainScript
%% Assignment3-2 
% Rollno: 163059009, 16305R011 

%% Init 
% Dictionary
K=20;
p=100;
D=randn(p,K);
for i=1:K;
    D(:,i)=D(:,i)/norm(D(:,i));
end
% signal
N=100;
X=zeros(N,p);
for i=1:N
    support=randi([1 20],1,5);
    coeff=randi([0 10],1,5);
    k=D(:,support)';
    X(:,i)=coeff*D(:,support)';
    
end

% phi
m=40; %to do for other m=[10,20,30,40,50,70,90]
f=[0.001, 0.01, 0.02, 0.05, 0.1, 0.3];
phi=zeros(m,p,N);
stdev=zeros(N,1);
y=zeros(m,N);
a = -1*(1/ sqrt(m));
b = 1/ sqrt(m);

for i=1:N
    for j=1:m
        for k=1:p
            if(randi([0,1],1)==0)
                phi(j,k,i) = a;
            else
                phi(j,k,i) = b;
            end
        end
    end
end

for i=1:N
    stdev(i)=f(1)*(1/m*N)*sum(norm((phi(:,:,i)*X(:,i)),1));
    noise=rand([m,1]).*stdev(i);
    y(:,i)=phi(:,:,i)*X(:,i)+noise(:);
end
[Dict,xCoeff]=ksvd(y,phi,stdev,X);

%% average relative error
rerr=0;
for i=1:N
    rerr=rerr+(norm(X(:,i)-(Dict*xCoeff(:,i)))/norm(X(:,i)));
    %fprintf('%f\n',norm((Dict*xCoeff(:,i))))
end
rerr=(1/N)*rerr;

